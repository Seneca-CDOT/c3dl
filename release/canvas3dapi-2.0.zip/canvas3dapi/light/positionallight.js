
c3dl.PositionalLight=function()
{this.position=[0,0,0];this.attenuation=[1,0,0];this.type=c3dl.POSITIONAL_LIGHT;this.getAttenuation=function()
{return[this.attenuation[0],this.attenuation[1],this.attenuation[2]];}
this.getPosition=function()
{return[this.position[0],this.position[1],this.position[2]];}
this.setAttenuation=function(attenuation)
{this.attenuation=attenuation;}
this.setPosition=function(vec)
{if(c3dl.isValidVector(vec))
{this.position=vec;}}}
c3dl.PositionalLight.prototype=new c3dl.Light;