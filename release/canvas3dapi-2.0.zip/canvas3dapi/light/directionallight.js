
c3dl.DirectionalLight=function()
{this.direction=[0,0,1];this.type=c3dl.DIRECTIONAL_LIGHT;this.getDirection=function()
{return[this.direction[0],this.direction[1],this.direction[2]]}
this.setDirection=function(dir)
{if(c3dl.isValidVector(dir))
{this.direction=c3dl.normalizeVector(dir);}}}
c3dl.DirectionalLight.prototype=new c3dl.Light;