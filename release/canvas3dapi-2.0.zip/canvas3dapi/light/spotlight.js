
c3dl.SpotLight=function()
{this.cutoff=180;this.type=c3dl.SPOT_LIGHT;this.direction=[0,0,-1];this.exponent=0;this.getCutoff=function()
{return this.cutoff;}
this.getDirection=function()
{return[this.direction[0],this.direction[1],this.direction[2]];}
this.getExponent=function()
{return this.exponent;}
this.setCutoff=function(cutoff)
{if((cutoff>=0&&cutoff<=90)||cutoff==180)
{this.cutoff=cutoff;}}
this.setDirection=function(dir)
{if(c3dl.isValidVector(dir))
{this.direction=c3dl.normalizeVector(dir);}}
this.setExponent=function(exponent)
{if(exponent>=0&&exponent<=128)
{this.exponent=exponent;}}}
c3dl.SpotLight.prototype=new c3dl.PositionalLight;