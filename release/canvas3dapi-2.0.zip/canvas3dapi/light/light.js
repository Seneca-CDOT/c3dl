
c3dl.Light=function()
{this.type=c3dl.ABSTRACT_LIGHT;this.name="unnamed";this.ambient=[0,0,0];this.diffuse=[0,0,0];this.specular=[0,0,0];this.on=false;this.getName=function()
{return this.name;}
this.getAmbient=function()
{return c3dl.copyObj(this.ambient);}
this.getDiffuse=function()
{return c3dl.copyObj(this.diffuse);}
this.getSpecular=function()
{return c3dl.copyObj(this.specular);}
this.getType=function()
{return this.type;}
this.isOn=function()
{return this.on;}
this.setOn=function(isOn)
{this.on=isOn;}
this.setName=function(name)
{this.name=name;}
this.setAmbient=function(color)
{if(color.length>=3)
{this.ambient=color.slice(0,3);}}
this.setDiffuse=function(color)
{if(color.length>=3)
{this.diffuse=color.slice(0,3);}}
this.setSpecular=function(color)
{if(color.length>=3)
{this.specular=color.slice(0,3);}}}