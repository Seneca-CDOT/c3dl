
c3dl.Point=function()
{this.color=[0,0,0];this.position=[0,0,0];this.visible=true;this.name="";this.getName=function()
{return this.name;}
this.setName=function(name)
{this.name=name;}
this.getPosition=function()
{return c3dl.copyObj(this.position);}
this.setPosition=function(pos)
{if(pos.length==3)
{this.position=c3dl.copyObj(pos);}
else
{c3dl.debug.logWarning("invalid value passed to Point::setPosition()");}}
this.getColor=function()
{return c3dl.copyObj(this.color);}
this.setColor=function(color)
{if(color.length==3)
{this.color=c3dl.copyObj(color);}
else
{c3dl.debug.logWarning("invalid value passed to Point::setColor()");}}
this.isVisible=function()
{return this.visible;}
this.setVisible=function(visible)
{this.visible=visible;}
this.getObjectType=function()
{return c3dl.POINT;}}