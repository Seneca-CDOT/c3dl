
c3dl.Actor=function()
{this.left=c3dl.makeVector(1.0,0.0,0.0);this.up=c3dl.makeVector(0.0,1.0,0.0);this.dir=c3dl.makeVector(0.0,0.0,1.0);this.pos=c3dl.makeVector(0.0,0.0,0.0);this.scaleVec=c3dl.makeVector(1.0,1.0,1.0);this.linVel=c3dl.makeVector(0.0,0.0,0.0);this.angVel=c3dl.makeVector(0.0,0.0,0.0);this.name="unnamed";}
c3dl.Actor.prototype.getPosition=function()
{return c3dl.makeVector(this.pos[0],this.pos[1],this.pos[2]);}
c3dl.Actor.prototype.getUp=function()
{return c3dl.makeVector(this.up[0],this.up[1],this.up[2]);}
c3dl.Actor.prototype.getDirection=function()
{return c3dl.makeVector(this.dir[0],this.dir[1],this.dir[2]);}
c3dl.Actor.prototype.getLeft=function()
{return c3dl.makeVector(this.left[0],this.left[1],this.left[2]);}
c3dl.Actor.prototype.getLinearVel=function()
{return c3dl.makeVector(this.linVel[0],this.linVel[1],this.linVel[2]);}
c3dl.Actor.prototype.getAngularVel=function()
{return c3dl.makeVector(this.angVel[0],this.angVel[1],this.angVel[2]);}
c3dl.Actor.prototype.getScale=function()
{return c3dl.makeVector(this.scaleVec[0],this.scaleVec[1],this.scaleVec[2]);}
c3dl.Actor.prototype.getTransform=function()
{var mat=c3dl.makePoseMatrix(this.left,this.up,this.dir,this.pos);var smat=c3dl.makeMatrix();c3dl.setMatrix(smat,this.scaleVec[0],0,0,0,0,this.scaleVec[1],0,0,0,0,this.scaleVec[2],0,0,0,0,1);mat=c3dl.multiplyMatrixByMatrix(mat,smat);return mat;}
c3dl.Actor.prototype.getName=function()
{return this.name;}
c3dl.Actor.prototype.setTransform=function(mat)
{this.left=c3dl.makeVector(mat[0],mat[1],mat[2]);this.up=c3dl.makeVector(mat[4],mat[5],mat[6]);this.dir=c3dl.makeVector(mat[8],mat[9],mat[10]);this.pos=c3dl.makeVector(mat[12],mat[13],mat[14]);}
c3dl.Actor.prototype.resetTransform=function()
{this.angVel=c3dl.makeVector(0.0,0.0,0.0);this.linVel=c3dl.makeVector(0.0,0.0,0.0);this.left=c3dl.makeVector(1.0,0.0,0.0);this.up=c3dl.makeVector(0.0,1.0,0.0);this.dir=c3dl.makeVector(0.0,0.0,1.0);this.pos=c3dl.makeVector(0.0,0.0,0.0);}
c3dl.Actor.prototype.scale=function(scaleVec)
{if(c3dl.isValidVector(scaleVec))
{if(scaleVec[0]>0.0&&scaleVec[1]>0.0&&scaleVec[2]>0.0)
{this.scaleVec=[this.scaleVec[0]*scaleVec[0],this.scaleVec[1]*scaleVec[1],this.scaleVec[2]*scaleVec[2]];}}
else
{c3dl.debug.logWarning('Actor::scale() called with a parameter that\'s not a vector');}}
c3dl.Actor.prototype.setPosition=function(vecPos)
{if(c3dl.isValidVector(vecPos))
{this.pos=vecPos;}
else
{c3dl.debug.logWarning("Actor::setPosition() called with a parameter that's not a vector");}}
c3dl.Actor.prototype.translate=function(translation)
{this.pos=c3dl.addVectors(this.pos,translation);}
c3dl.Actor.prototype.setForward=function(newVec)
{if(c3dl.isValidVector(newVec))
{this.dir=this.pos;c3dl.subtractVectors(this.dir,newVec,this.dir);c3dl.normalizeVector(this.dir);c3dl.vectorCrossProduct(this.up,this.dir,this.left);c3dl.normalizeVector(this.left);c3dl.vectorCrossProduct(this.dir,this.up,this.up);c3dl.normalizeVector(this.up);}
else
{c3dl.debug.logWarning('Actor::setForward() called with a parameter that\'s not a vector');}}
c3dl.Actor.prototype.setUpVector=function(newVec)
{if(c3dl.isValidVector(newVec))
{this.up=newVec;}
else
{c3dl.debug.logWarning('Actor::setUpVector() called with a parameter that\'s not a vector');}}
c3dl.Actor.prototype.setLinearVel=function(newVec)
{if(c3dl.isValidVector(newVec))
{this.linVel=newVec;}
else
{c3dl.debug.logWarning('Actor::setLinearVel() called with a parameter that\'s not a vector');}}
c3dl.Actor.prototype.setAngularVel=function(newVec)
{if(c3dl.isValidVector(newVec))
{this.angVel=newVec;}
else
{c3dl.debug.logWarning("Actor's setAngularVel() called with a parameter that's not a vector");}}
c3dl.Actor.prototype.setName=function(name)
{this.name=name;}
c3dl.Actor.prototype.rotateOnAxis=function(axisVec,angle)
{var rotateOnAxisQuat=c3dl.makeQuat(0,0,0,0);var rotateOnAxisMat=c3dl.makeZeroMatrix();if(!c3dl.isValidVector(axisVec))
{c3dl.debug.logWarning('Actor::rotateOnAxis() called with the first parameter not a vector');return;}
if(isNaN(angle))
{c3dl.debug.logWarning('Actor::rotateOnAxis() called with the second parameter not a number');return;}
if(angle==0)
{return;}
c3dl.axisAngleToQuat(axisVec,angle,rotateOnAxisQuat);rotateOnAxisMat=c3dl.quatToMatrix(rotateOnAxisQuat);c3dl.multiplyMatrixByVector(rotateOnAxisMat,this.dir,this.dir);c3dl.normalizeVector(this.dir);c3dl.multiplyMatrixByVector(rotateOnAxisMat,this.left,this.left);c3dl.normalizeVector(this.left);c3dl.multiplyMatrixByVector(rotateOnAxisMat,this.up,this.up);c3dl.normalizeVector(this.up);}
c3dl.Actor.prototype.yaw=function(angle)
{if(angle!=0)
{this.rotateOnAxis(this.up,angle);}}
c3dl.Actor.prototype.roll=function(angle)
{if(angle!=0)
{this.rotateOnAxis(this.dir,angle);}}
c3dl.Actor.prototype.pitch=function(angle)
{if(angle!=0)
{this.rotateOnAxis(this.left,angle);}}
c3dl.Actor.prototype.update=function(timeStep)
{if(timeStep<500)
{var velVec=this.linVel;c3dl.multiplyVector(velVec,timeStep);c3dl.addVectors(this.pos,velVec,this.pos);this.pitch(this.angVel[0]*timeStep);this.yaw(this.angVel[1]*timeStep);this.roll(this.angVel[2]*timeStep);}}
c3dl.Actor.prototype.getCopy=function()
{var actor=new c3dl.Actor();actor.clone(this);return actor;}
c3dl.Actor.getObjectType=function()
{return c3dl.COLLADA;}
c3dl.Actor.prototype.clone=function(other)
{this.left=c3dl.copyVector(other.left);this.up=c3dl.copyVector(other.up);this.dir=c3dl.copyVector(other.dir);this.pos=c3dl.copyVector(other.pos);this.scaleVec=c3dl.copyVector(other.scaleVec);this.linVel=c3dl.copyVector(other.linVel);this.angVel=c3dl.copyVector(other.angVel);this.name=other.name;}