
c3dl.PrimitiveSet=function()
{this.material=null;this.texture=null;this.vertices=null;this.normals=null;this.texCoords=null;this.boundingSphere=null;this.buffers={};this.init=function(vertices,normals,texCoords)
{this.vertices=vertices;this.normals=normals;this.texCoords=texCoords;this.boundingSphere=new c3dl.BoundingSphere();this.boundingSphere.init(this.vertices);this.boundingSphere.setPosition([0,0,0]);}
this.setupVBO=function(glCanvas3D)
{this.buffers.vertices=glCanvas3D.createBuffer();this.buffers.normals=glCanvas3D.createBuffer();this.buffers.texCoords=glCanvas3D.createBuffer();glCanvas3D.bindBuffer(glCanvas3D.ARRAY_BUFFER,this.buffers.vertices);glCanvas3D.bufferData(glCanvas3D.ARRAY_BUFFER,new WebGLFloatArray(this.vertices),glCanvas3D.STATIC_DRAW);glCanvas3D.bindBuffer(glCanvas3D.ARRAY_BUFFER,this.buffers.normals);glCanvas3D.bufferData(glCanvas3D.ARRAY_BUFFER,new WebGLFloatArray(this.normals),glCanvas3D.STATIC_DRAW);glCanvas3D.bindBuffer(glCanvas3D.ARRAY_BUFFER,this.buffers.texCoords);glCanvas3D.bufferData(glCanvas3D.ARRAY_BUFFER,new WebGLFloatArray(this.texCoords),glCanvas3D.STATIC_DRAW);}
this.getVBOVertices=function()
{return this.buffers.vertices;}
this.getVBONormals=function()
{return this.buffers.normals;}
this.getVBOTexCoords=function()
{return this.buffers.texCoords;}
this.getCopy=function()
{var copy=new c3dl.PrimitiveSet();copy.vertices=this.vertices;copy.normals=this.normals;copy.texCoords=this.texCoords;copy.boundingSphere=this.boundingSphere;copy.texture=this.texture;copy.material=this.material?this.material.getCopy():null;return copy;}
this.getTexture=function()
{return this.texture;}
this.getVertices=function()
{return this.vertices;}
this.getNormals=function()
{return this.normals;}
this.getTexCoords=function()
{return this.texCoords;}
this.getMaterial=function()
{return this.material;}
this.getBoundingSphere=function()
{return this.boundingSphere;}
this.setMaterial=function(material)
{this.material=material;}
this.setTexture=function(texture)
{this.texture=texture;}}