
c3dl.PickingResult=function()
{this.getButtonUsed=function(){}
this.getCanvas=function(){}
this.getObjects=function(){}}