
c3dl.point_fs="void main(void){ "+" gl_FragColor = gl_Color;"+"}";