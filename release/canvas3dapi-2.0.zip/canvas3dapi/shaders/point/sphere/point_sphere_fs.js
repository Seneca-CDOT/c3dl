
c3dl.point_sphere_fs="void main(void){ "+" gl_FragColor = gl_Color;"+"}";