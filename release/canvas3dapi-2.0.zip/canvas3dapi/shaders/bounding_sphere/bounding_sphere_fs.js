
c3dl.bounding_sphere_fs="void main(void) {"+"  gl_FragColor = gl_Color;"+"}";