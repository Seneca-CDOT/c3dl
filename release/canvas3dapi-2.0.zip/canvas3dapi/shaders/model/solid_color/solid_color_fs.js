
c3dl.solid_color_fs="void main(void) {"+"  gl_FragColor = gl_Color;"+"}";