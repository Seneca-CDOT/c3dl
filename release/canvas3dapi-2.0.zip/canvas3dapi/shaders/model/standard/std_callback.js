
var isDone=false;c3dl.std_callback=function(renderingObj)
{var progObjID=renderingObj.getProgramObjectID();var geometry=renderingObj.getGeometry();var renderer=renderingObj.getRenderer();var glCanvas3D=renderingObj.getContext();glCanvas3D.useProgram(progObjID);var modelViewMatrix=c3dl.peekMatrix();c3dl.matrixMode(c3dl.PROJECTION);var projectionMatrix=c3dl.peekMatrix();c3dl.matrixMode(c3dl.MODELVIEW);var modelViewProjMatrix=c3dl.multiplyMatrixByMatrix(projectionMatrix,modelViewMatrix);renderer.setUniformMatrix(progObjID,"modelViewMatrix",modelViewMatrix);renderer.setUniformMatrix(progObjID,"modelViewProjMatrix",modelViewProjMatrix);for(var coll=0;coll<geometry.getPrimitiveSets().length;coll++)
{var currColl=geometry.getPrimitiveSets()[coll];var mat=currColl.getMaterial();if(mat)
{renderer.setUniformf(progObjID,"material.emission",mat.getEmission());renderer.setUniformf(progObjID,"material.ambient",mat.getAmbient());renderer.setUniformf(progObjID,"material.diffuse",mat.getDiffuse());renderer.setUniformf(progObjID,"material.specular",mat.getSpecular());renderer.setUniformf(progObjID,"material.shininess",mat.getShininess());renderer.setUniformi(progObjID,"usingMaterial",true);}
else
{renderer.setUniformi(progObjID,"usingMaterial",false);}
var normalAttribLoc=glCanvas3D.getAttribLocation(progObjID,"Normal");if(normalAttribLoc!=-1&&currColl.getNormals())
{var NormalMatrix=c3dl.inverseMatrix(modelViewMatrix);NormalMatrix=c3dl.transposeMatrix(NormalMatrix);renderer.setUniformMatrix(progObjID,"normalMatrix",NormalMatrix);renderer.setVertexAttribArray(progObjID,"Normal",3,currColl.getVBONormals());}
else
{glCanvas3D.disableVertexAttribArray(normalAttribLoc);}
var usingTexture=false;var texAttribLoc=glCanvas3D.getAttribLocation(progObjID,"Texture");var texID=renderer.texManager.getID(currColl.getTexture());if(texID==-1&&currColl.getTexture())
{renderer.texManager.addTexture(currColl.getTexture());}
if(texID!=-1&&currColl.getTexture()&&currColl.getTexCoords()&&texAttribLoc!=-1)
{glCanvas3D.activeTexture(glCanvas3D.TEXTURE0);glCanvas3D.bindTexture(glCanvas3D.TEXTURE_2D,texID);renderer.setVertexAttribArray(progObjID,"Texture",2,currColl.getVBOTexCoords());usingTexture=true;}
else
{glCanvas3D.activeTexture(glCanvas3D.TEXTURE0);glCanvas3D.disableVertexAttribArray(texAttribLoc);}
renderer.setUniformi(progObjID,"usingTexture",usingTexture);renderer.setUniformi(progObjID,"lightingOn",true);renderer.setVertexAttribArray(progObjID,"Vertex",3,currColl.getVBOVertices());glCanvas3D.drawArrays(renderer.getFillMode(),0,currColl.getVertices().length/3);}}