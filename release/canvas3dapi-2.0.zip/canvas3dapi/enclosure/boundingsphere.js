
c3dl.BoundingSphere=function()
{this.longestVector=[0,0,0];this.original=[0,0,0];this.position=[0,0,0];this.radius=0;this.init=function(vertices)
{var longestLengthFound=0;var vector=[0,0,0];var currVector;for(var i=0;i<vertices.length;i+=3)
{vector[0]=vertices[i+0];vector[1]=vertices[i+1];vector[2]=vertices[i+2];currVector=c3dl.vectorLength(vector);if(currVector>longestLengthFound)
{longestLengthFound=currVector;this.longestVector=[vertices[i+0],vertices[i+1],vertices[i+2]];}}
this.original[0]=this.longestVector[0];this.original[1]=this.longestVector[1];this.original[2]=this.longestVector[2];}
this.setPosition=function(position)
{this.position=[position[0],position[1],position[2]];}
this.scale=function(scaleVec)
{var largestScale=scaleVec[0]>scaleVec[1]?scaleVec[0]:scaleVec[1];largestScale=largestScale>scaleVec[2]?largestScale:scaleVec[2];this.longestVector[0]=this.original[0]*largestScale;this.longestVector[1]=this.original[1]*largestScale;this.longestVector[2]=this.original[2]*largestScale;}
this.render=function(scene)
{if(scene.getBoundingVolumeVisibility())
{scene.getRenderer().renderBoundingSphere(this);}}
this.getRadius=function()
{return c3dl.vectorLength(this.longestVector);}
this.getPosition=function()
{return[this.position[0],this.position[1],this.position[2]];}}