
c3dl.FreeCamera=c3dl.inherit(c3dl.Camera,function()
{c3dl._superc(this);this.linVel=[0.0,0.0,0.0];this.angVel=[0.0,0.0,0.0];});c3dl.FreeCamera.prototype.getAngularVel=function()
{return[this.angVel[0],this.angVel[1],this.angVel[2]];}
c3dl.FreeCamera.prototype.getLinearVel=function()
{return[this.linVel[0],this.linVel[1],this.linVel[2]];}
c3dl.FreeCamera.prototype.pitch=function(angle)
{this.rotateOnAxis(this.left,angle);}
c3dl.FreeCamera.prototype.roll=function(angle)
{this.rotateOnAxis(this.dir,angle);}
c3dl.FreeCamera.prototype.rotateOnAxis=function(axisVec,angle)
{if(!c3dl.isValidVector(axisVec))
{c3dl.debug.logWarning('FreeCamera::rotateOnAxis() called with the first parameter not a vector');return;}
if(isNaN(angle))
{c3dl.debug.logWarning('FreeCamera::rotateOnAxis() called with the second parameter not a number');return;}
var quat=c3dl.axisAngleToQuat(axisVec,angle);var mat=c3dl.quatToMatrix(quat);c3dl.multiplyMatrixByVector(mat,this.dir,this.dir);c3dl.normalizeVector(this.dir);c3dl.multiplyMatrixByVector(mat,this.left,this.left);c3dl.normalizeVector(this.left);c3dl.multiplyMatrixByVector(mat,this.up,this.up);c3dl.normalizeVector(this.up);}
c3dl.FreeCamera.prototype.setAngularVel=function(newVec)
{if(c3dl.isValidVector(newVec))
{this.angVel=c3dl.makeVector(newVec[0],newVec[1],newVec[2]);}
else
{c3dl.debug.logWarning('FreeCamera::setAngularVel() called with a parameter that\'s not a vector');}}
c3dl.FreeCamera.prototype.setLinearVel=function(newVec)
{if(c3dl.isValidVector(newVec))
{this.linVel=c3dl.makeVector(newVec[0],newVec[1],newVec[2]);}
else
{c3dl.debug.logWarning('FreeCamera::setLinearVel() called with a parameter that\'s not a vector');}}
c3dl.FreeCamera.prototype.setLookAtPoint=function(newVec)
{if(c3dl.isValidVector(newVec))
{if(c3dl.isVectorEqual(this.pos,[0,0,0])&&c3dl.isVectorEqual(newVec,[0,0,0]))
{c3dl.debug.logWarning("Cannot lookAt [0,0,0] since camera is at [0,0,0]."+" Move camera before calling setLookAt()");}
else
{this.dir=c3dl.subtractVectors(newVec,this.pos);c3dl.normalizeVector(this.dir);c3dl.vectorCrossProduct([0,1,0],this.dir,this.left);c3dl.normalizeVector(this.left);c3dl.vectorCrossProduct(this.dir,this.left,this.up);c3dl.normalizeVector(this.up);}}
else
{c3dl.debug.logWarning("FreeCamera::setLookAtPoint() called with a parameter that's not a vector");}}
c3dl.FreeCamera.prototype.setPosition=function(newVec)
{if(c3dl.isValidVector(newVec))
{this.pos=newVec;}
else
{c3dl.debug.logWarning("FreeCamera::setPosition() called with a parameter that's not a vector");}}
c3dl.FreeCamera.prototype.setUpVector=function(newVec)
{if(c3dl.isValidVector(newVec))
{this.up=c3dl.makeVector(newVec[0],newVec[1],newVec[2]);}
else
{c3dl.debug.logWarning('FreeCamera::setUpVector() called with a parameter that\'s not a vector');}}
c3dl.FreeCamera.prototype.toString=function(delimiter)
{if(!delimiter||typeof(delimiter)!="string")
{delimiter=",";}
var cameraToStr=c3dl._super(this,arguments,"toString");var FreeCameraToStr="c3dl.FreeCamera: "+delimiter+"angular velocity = "+this.getAngularVel()+delimiter+"linear velocity = "+this.getLinearVel()+delimiter;return cameraToStr+FreeCameraToStr;}
c3dl.FreeCamera.prototype.update=function(timeStep)
{if(c3dl.isVectorZero(this.linVel)&&c3dl.isVectorZero(this.angVel))
{return false;}
if(c3dl.vectorLengthSq(this.linVel)>0.0)
{var velVec=c3dl.makeVector(this.linVel[0],this.linVel[1],this.linVel[2]);c3dl.multiplyVector(velVec,timeStep,velVec);c3dl.addVectors(this.pos,velVec,this.pos);}
if(c3dl.vectorLengthSq(this.angVel)>0.0)
{this.pitch(this.angVel[0]*timeStep);this.yaw(this.angVel[1]*timeStep);this.roll(this.angVel[2]*timeStep);}}
c3dl.FreeCamera.prototype.yaw=function(angle)
{this.rotateOnAxis(this.up,angle);}