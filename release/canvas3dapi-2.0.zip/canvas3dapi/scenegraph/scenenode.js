
c3dl.SceneNode=c3dl.inherit(c3dl.Primitive,function()
{c3dl._superc(this);this.children=[];});c3dl.SceneNode.prototype.getCopy=function()
{var sceneNode=new c3dl.SceneNode();sceneNode.clone(this);return sceneNode;}
c3dl.SceneNode.prototype.clone=function(other)
{c3dl._super(this,arguments,"clone");for(var i=0;i<other.children.length;i++)
{this.addChild(other.children[i].getCopy());}}
c3dl.SceneNode.prototype.addChild=function(child)
{this.children.push(child);}
c3dl.SceneNode.prototype.findNode=function(nodeName)
{var child=null;if(nodeName==this.name)
{child=this;}
else
{for(var i=0;i<this.children.length;i++)
{if(this.children[i]instanceof c3dl.SceneNode)
{child=this.children[i].findNode(nodeName);if(child!=null)
{break;}}}}
return child;}
c3dl.SceneNode.prototype.update=function(timeStep)
{c3dl._super(this,arguments,"update");for(var i=0;i<this.children.length;i++)
{this.children[i].update(timeStep);}}
c3dl.SceneNode.prototype.render=function(glCanvas3D,scene)
{c3dl.pushMatrix();c3dl.multMatrix(this.getTransform());for(var i=0;i<this.children.length;i++)
{this.children[i].render(glCanvas3D,scene);}
c3dl.popMatrix();}
c3dl.SceneNode.prototype.setTexture=function(textureName)
{for(var i=0;i<this.children.length;i++)
{this.children[i].setTexture(textureName);}}
c3dl.SceneNode.prototype.setMaterial=function(material)
{for(var i=0;i<this.children.length;i++)
{this.children[i].setMaterial(material);}}
c3dl.SceneNode.prototype.setEffect=function(effect)
{for(var i=0;i<this.children.length;i++)
{this.children[i].setEffect(effect);}}
c3dl.SceneNode.prototype.rayIntersectsTriangles=function(rayOrigin,rayDir)
{c3dl.pushMatrix();c3dl.multMatrix(this.getTransform());var passed=false;for(var i=0;i<this.children.length;i++)
{if(this.children[i].rayIntersectsTriangles(rayOrigin,rayDir))
{passed=true;break;}}
c3dl.popMatrix();return passed;}
c3dl.SceneNode.prototype.rayIntersectsEnclosures=function(rayOrigin,rayDir)
{c3dl.pushMatrix();c3dl.multMatrix(this.getTransform());var passed=false;for(var i=0;i<this.children.length;i++)
{if(this.children[i].rayIntersectsEnclosures(rayOrigin,rayDir))
{passed=true;break;}}
c3dl.popMatrix();return passed;}