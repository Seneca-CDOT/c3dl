
c3dl.isValidVector=function(vecArr)
{if(vecArr instanceof Array)
{if(vecArr.length==3||vecArr.length==4)
{for(var i=0;i<vecArr.length;i++)
{if(isNaN(vecArr[i]))
return false;}
return true;}}
return false;}
c3dl.copyVector=function(srcVec)
{return c3dl.makeVector(srcVec[0],srcVec[1],srcVec[2]);}
c3dl.copyVectorContents=function(srcVec,destVec)
{if(!c3dl.isValidVector(srcVec)||!c3dl.isValidVector(destVec))
{c3dl.debug.logWarning("copyVectorContents() didn't get two vectors as parameters");return;}
destVec[0]=srcVec[0];destVec[1]=srcVec[1];destVec[2]=srcVec[2];}
c3dl.makeVector=function(newX,newY,newZ)
{var vec=[!isNaN(newX)?parseFloat(newX):0.0,!isNaN(newY)?parseFloat(newY):0.0,!isNaN(newZ)?parseFloat(newZ):0.0];return vec;}
c3dl.normalizeVector=function(vec)
{if(c3dl.isValidVector(vec))
{var compr=vec[0]*vec[0]+vec[1]*vec[1]+vec[2]*vec[2];if(!isNaN(compr))
{var ln=Math.sqrt(compr);if(!isNaN(ln)&&ln!=0.0)
{vec[0]=vec[0]!=0.0?vec[0]/ln:0.0;vec[1]=vec[1]!=0.0?vec[1]/ln:0.0;vec[2]=vec[2]!=0.0?vec[2]/ln:0.0;return vec;}
else
{c3dl.debug.logWarning('normalizeVector() called with a vector of length 0');}}
else
{c3dl.debug.logWarning('normalizeVector() called with a vector with compr 0');}}
c3dl.debug.logWarning('normalizeVector() called with a parameter that\'s not a vector');return null;}
c3dl.vectorDotProduct=function(vecOne,vecTwo)
{if(c3dl.isValidVector(vecOne)&&c3dl.isValidVector(vecTwo))
{return parseFloat(vecOne[0]*vecTwo[0]+vecOne[1]*vecTwo[1]+vecOne[2]*vecTwo[2]);}
else
{c3dl.debug.logWarning('vectorDotProduct() called with a parameter that\'s not a vector');return null;}}
c3dl.vectorProject=function(vecOne,vecTwo)
{var topDot=c3dl.vectorDotProduct(vecOne,vecTwo);var bottomDot=c3dl.vectorDotProduct(vecTwo,vecTwo);return c3dl.multiplyVector(vecTwo,topDot/bottomDot);}
c3dl.vectorCrossProduct=function(vecOne,vecTwo,dest)
{if(c3dl.isValidVector(vecOne)&&c3dl.isValidVector(vecTwo))
{var thisVec=vecOne;var inVec=vecTwo;if(typeof(dest)=="undefined"||dest==null)
dest=c3dl.makeVector();dest[0]=thisVec[1]*inVec[2]-thisVec[2]*inVec[1];dest[1]=thisVec[2]*inVec[0]-thisVec[0]*inVec[2];dest[2]=thisVec[0]*inVec[1]-thisVec[1]*inVec[0];return dest;}
c3dl.debug.logWarning('vectorCrossProduct() called with a parameter that\'s not a vector');return null;}
c3dl.vectorLength=function(vec)
{if(c3dl.isValidVector(vec))
{return Math.sqrt(vec[0]*vec[0]+vec[1]*vec[1]+vec[2]*vec[2]);}
c3dl.debug.logWarning('vectorLength() called with a parameter that\'s not a vector');return null;}
c3dl.vectorLengthSq=function(vec)
{if(c3dl.isValidVector(vec))
{return(vec[0]*vec[0]+vec[1]*vec[1]+vec[2]*vec[2]);}
c3dl.debug.logWarning('vectorLengthSq() called with a parameter that\'s not a vector');return null;}
c3dl.addVectors=function(vecOne,vecTwo,dest)
{if(c3dl.isValidVector(vecOne)&&c3dl.isValidVector(vecTwo))
{if(typeof(dest)=="undefined"||dest==null)
dest=c3dl.makeVector();dest[0]=vecOne[0]+vecTwo[0];dest[1]=vecOne[1]+vecTwo[1];dest[2]=vecOne[2]+vecTwo[2];return dest;}
c3dl.debug.logWarning('addVectors() called with invalid parameters');return null;}
c3dl.subtractVectors=function(vecOne,vecTwo,dest)
{if(c3dl.isValidVector(vecOne)&&c3dl.isValidVector(vecTwo))
{if(typeof(dest)=="undefined"||dest==null)
dest=c3dl.makeVector();dest[0]=vecOne[0]-vecTwo[0];dest[1]=vecOne[1]-vecTwo[1];dest[2]=vecOne[2]-vecTwo[2];return dest;}
c3dl.debug.logWarning('subtractVectors() called with invalid parameters');return null;}
c3dl.multiplyVector=function(vec,scalar,dest)
{if(c3dl.isValidVector(vec)&&!isNaN(scalar))
{if(typeof(dest)=="undefined"||dest==null)
dest=c3dl.makeVector();dest[0]=vec[0]*scalar;dest[1]=vec[1]*scalar;dest[2]=vec[2]*scalar;return dest;}
c3dl.debug.logWarning('multiplyVector() called with invalid parameters');return null;}
c3dl.divideVector=function(vec,scalar,dest)
{if(c3dl.isValidVector(vec)&&!isNaN(scalar))
{if(scalar==0)
{c3dl.debug.logWarning('divideVector() called with scalar 0');return null;}
if(typeof(dest)=="undefined"||dest==null)
dest=c3dl.makeVector();dest[0]=vec[0]/scalar;dest[1]=vec[1]/scalar;dest[2]=vec[2]/scalar;return dest;}
c3dl.debug.logWarning('divideVector() called with invalid parameters');return null;}
c3dl.multiplyVectorByVector=function(vecOne,vecTwo,dest)
{if(c3dl.isValidVector(vecOne)&&c3dl.isValidVector(vecTwo))
{if(typeof(dest)=="undefined"||dest==null)
dest=c3dl.makeVector();dest[0]=vecOne[0]*vecTwo[0];dest[1]=vecOne[1]*vecTwo[1];dest[2]=vecOne[2]*vecTwo[2];return dest;}
c3dl.debug.logWarning('multiplyVectorByVector() called with invalid parameters');return null;}
c3dl.isVectorEqual=function(vecOne,vecTwo)
{if(c3dl.isValidVector(vecOne)&&c3dl.isValidVector(vecTwo))
{return(vecOne[0]==vecTwo[0]&&vecOne[1]==vecTwo[1]&&vecOne[2]==vecTwo[2]);}
c3dl.debug.logWarning('isVectorEqual() called with invalid parameters');return null;}
c3dl.isVectorZero=function(vec)
{if(c3dl.isValidVector(vec))
{return((-c3dl.TOLERANCE<vec[0]&&vec[0]<c3dl.TOLERANCE)&&(-c3dl.TOLERANCE<vec[1]&&vec[1]<c3dl.TOLERANCE)&&(-c3dl.TOLERANCE<vec[2]&&vec[2]<c3dl.TOLERANCE));}
return false;}
c3dl.getAngleBetweenVectors=function(vecOne,vecTwo)
{var dot=c3dl.vectorDotProduct(vecOne,vecTwo);return c3dl.radiansToDegrees(Math.acos(dot));}