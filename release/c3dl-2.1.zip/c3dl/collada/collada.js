
c3dl.Collada=c3dl.inherit(c3dl.Primitive,function(){c3dl._superc(this);this.boundingbox=new c3dl.BoundingBox();this.drawboundingbox=false;this.path=null;this.sceneGraph=null;});c3dl.Collada.prototype.getPath=function(){if(this.isReady()){return this.path;}}
c3dl.Collada.prototype.getAngularVel=function(){if(this.isReady()){return this.sceneGraph.getAngularVel();}}
c3dl.Collada.prototype.getLinearVel=function(){if(this.isReady()){return this.sceneGraph.getLinearVel();}}
c3dl.Collada.prototype.getPosition=function(){if(this.isReady()){return this.sceneGraph.getPosition();}}
c3dl.Collada.prototype.setAngularVel=function(vec){if(this.isReady()){this.sceneGraph.setAngularVel(vec);}}
c3dl.Collada.prototype.getUp=function(){if(this.isReady()){return this.sceneGraph.getUp();}}
c3dl.Collada.prototype.getLeft=function(){if(this.isReady()){return this.sceneGraph.getLeft();}}
c3dl.Collada.prototype.getDirection=function(){if(this.isReady()){return this.sceneGraph.getDirection();}}
c3dl.Collada.prototype.getPickable=function(){if(this.isReady()){return this.sceneGraph.getPickable();}}
c3dl.Collada.prototype.setPickable=function(isPickable){if(this.isReady()){this.sceneGraph.setPickable(isPickable);}}
c3dl.Collada.prototype.setLinearVel=function(vec){if(this.isReady()){this.sceneGraph.setLinearVel(vec);}}
c3dl.Collada.prototype.init=function(daePath){this.path=daePath;if(c3dl.ColladaManager.isFileLoaded(this.path)){this.sceneGraph=c3dl.ColladaManager.getSceneGraphCopy(this.path);}
else{c3dl.ColladaQueue.pushBack(this);}
if(this.isReady()){c3dl.pushMatrix();c3dl.loadIdentity();this.boundingbox.init(this.sceneGraph.getAllVerts());c3dl.popMatrix();}}
c3dl.Collada.prototype.update=function(timeStep){if(this.isReady()){c3dl.pushMatrix();c3dl.loadIdentity();this.sceneGraph.update(timeStep);c3dl.popMatrix();var angVel=this.sceneGraph.getAngularVel();this.boundingbox.rotateOnAxis(this.sceneGraph.left,angVel[0]*timeStep);this.boundingbox.rotateOnAxis(this.sceneGraph.up,angVel[1]*timeStep);this.boundingbox.rotateOnAxis(this.sceneGraph.dir,angVel[2]*timeStep);var linVel=this.sceneGraph.getLinearVel();linVel=c3dl.multiplyVector(linVel,timeStep);var tempPos=c3dl.addVectors(this.sceneGraph.getPosition(),linVel);this.boundingbox.setPosition(tempPos);}
else{c3dl.debug.logError('You must call addModel("'+this.path+'"); before canvasMain.');if(c3dl.ColladaManager.isFileLoaded(this.path)){this.sceneGraph=c3dl.ColladaManager.getSceneGraphCopy(this.path);}}}
c3dl.Collada.prototype.setSceneGraph=function(sg){this.sceneGraph=sg;}
c3dl.Collada.prototype.render=function(glCanvas3D,scene){if(this.sceneGraph&&this.isVisible()){this.sceneGraph.render(glCanvas3D,scene);if(this.drawboundingbox){this.boundingbox.render(scene);}}}
c3dl.Collada.prototype.scale=function(scaleVec){if(this.isReady()){this.boundingbox.scale(scaleVec);this.sceneGraph.scale(scaleVec);}}
c3dl.Collada.prototype.translate=function(trans){if(this.isReady()){this.sceneGraph.translate(trans);this.boundingbox.setPosition(trans);}}
c3dl.Collada.prototype.setPosition=function(pos){if(this.isReady()){this.sceneGraph.setPosition(pos);this.boundingbox.setPosition(pos);}}
c3dl.Collada.prototype.getSceneGraph=function(){return this.sceneGraph;}
c3dl.Collada.prototype.setTexture=function(texturePath){if(this.isReady()){this.sceneGraph.setTexture(texturePath);}}
c3dl.Collada.prototype.setMaterial=function(material){if(this.isReady()){this.sceneGraph.setMaterial(material);}}
c3dl.Collada.prototype.setEffect=function(effect){this.sceneGraph.setEffect(effect);}
c3dl.Collada.prototype.rotateOnAxis=function(axisVec,angle){if(this.isReady()){this.sceneGraph.rotateOnAxis(axisVec,angle);this.boundingbox.rotateOnAxis(axisVec,angle);}}
c3dl.Collada.prototype.yaw=function(angle){if(this.isReady()){this.sceneGraph.yaw(angle);this.boundingbox.rotateOnAxis(this.sceneGraph.up,angle);}}
c3dl.Collada.prototype.pitch=function(angle){if(this.isReady()){this.sceneGraph.pitch(angle);this.boundingbox.rotateOnAxis(this.sceneGraph.left,angle);}}
c3dl.Collada.prototype.isReady=function(){return this.sceneGraph!=null?true:false;}
c3dl.Collada.prototype.roll=function(angle){if(this.isReady()){this.sceneGraph.roll(angle);this.boundingbox.rotateOnAxis(this.sceneGraph.dir,angle);}}
c3dl.Collada.prototype.getCopy=function(){var collada=new Collada();collada.clone(this);return collada;}
c3dl.Collada.prototype.getTransform=function(){if(this.sceneGraph){return this.sceneGraph.getTransform();}}
c3dl.Collada.prototype.clone=function(other){c3dl._super(this,arguments,"clone");this.path=other.path;this.sceneGraph=other.sceneGraph.getCopy();this.boundingbox=other.boundingbox.getCopy();}
c3dl.Collada.prototype.rayIntersectsEnclosures=function(rayOrigin,rayDir){var result=this.sceneGraph.rayIntersectsEnclosures(rayOrigin,rayDir);return result;}
c3dl.Collada.prototype.getObjectType=function(){return c3dl.COLLADA;}
c3dl.Collada.prototype.rayIntersectsTriangles=function(rayOrigin,rayDir){c3dl.pushMatrix();c3dl.loadIdentity();var result=this.sceneGraph.rayIntersectsTriangles(rayOrigin,rayDir);c3dl.popMatrix();return result;}
c3dl.Collada.prototype.getBoundingSpheres=function(){return this.sceneGraph.getBoundingSpheres();}
c3dl.Collada.prototype.getHeight=function(){if(this.isReady()){return this.boundingbox.getHeight();}}
c3dl.Collada.prototype.getWidth=function(){if(this.isReady()){return this.boundingbox.getWidth();}}
c3dl.Collada.prototype.getLength=function(){if(this.isReady()){return this.boundingbox.getLength();}}
c3dl.Collada.prototype.setHeight=function(height){var curheight=this.getHeight();var scaleVec=[];if(curheight>height){scaleVec=[1,(1/(curheight/height)),1];}
else if(curheight<height){scaleVec=[1,(height/curheight),1];}
else{scaleVec[1,1,1];}
this.boundingbox.scale(scaleVec);this.sceneGraph.scale(scaleVec);}
c3dl.Collada.prototype.setLength=function(length){var curlength=this.getLength();var scaleVec=[];if(curlength>length){scaleVec=[(1/(curlength/length)),1,1];}
else if(curlength<length){scaleVec=[(length/curlength),1,1];}
else{scaleVec[1,1,1];}
this.boundingbox.scale(scaleVec);this.sceneGraph.scale(scaleVec);}
c3dl.Collada.prototype.setWidth=function(width){var curwidth=this.getWidth();var scaleVec=[];if(curwidth>width){scaleVec=[1,1,(1/(curwidth/width))];}
else if(curwidth<width){scaleVec=[1,1,(width/curwidth)];}
else{scaleVec[1,1,1];}
this.boundingbox.scale(scaleVec);this.sceneGraph.scale(scaleVec);}
c3dl.Collada.prototype.setSize=function(length,width,height){length=parseFloat(length);width=parseFloat(width);height=parseFloat(height);var curlength=this.boundingbox.getLength();var curwidth=this.boundingbox.getWidth();var curheight=this.boundingbox.getHeight();var scaleVec=[];var vecL,vecW,vecH;if(curlength>length){vecL=(1/(curlength/length));}
else if(curlength<length){vecL=length/curlength;}
else{vecL=1;}
if(curheight>height){vecH=(1/(curheight/height));}
else if(curheight<height){vecH=(height/curheight);}
else{vecH=1;}
if(curwidth>width){vecW=(1/(curwidth/width));}
else if(curwidth<width){vecW=(width/curwidth);}
else{vecW=1;}
scaleVec=[vecL,vecH,vecW];this.scale(scaleVec);}
c3dl.Collada.prototype.setDrawBoundingBox=function(drawboundingbox){this.drawboundingbox=drawboundingbox;}
c3dl.Collada.prototype.getBoundingBox=function(){return this.boundingbox;}
c3dl.Collada.prototype.getBoundingBoxCorners=function(){return this.boundingbox.getCorners();}
c3dl.Collada.prototype.centerObject=function(){this.sceneGraph.center(this.boundingbox.realposition);this.boundingbox.center();}