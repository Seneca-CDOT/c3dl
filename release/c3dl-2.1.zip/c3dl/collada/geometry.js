
c3dl.Geometry=function(){this.primitiveSets=[];this.effect=null;this.firstTimeRender=true;this.addPrimitiveSet=function(primitiveSet){this.primitiveSets.push(primitiveSet);}
this.clone=function(other){for(var i=0,len=other.primitiveSets.length;i<len;i++){this.primitiveSets.push(other.primitiveSets[i].getCopy());}}
this.getCopy=function(){var geometry=new c3dl.Geometry();geometry.clone(this);return geometry;}
this.getEffect=function(){return this.effect;}
this.getPrimitiveSets=function(){return this.primitiveSets;}
this.rayIntersectsEnclosures=function(rayOrigin,rayDir){for(var i=0,len=this.primitiveSets.length;i<len;i++){if(this.getPrimitiveSets()[i].getType()!=="lines"){var bs=this.primitiveSets[i].getBoundingSphere();var pos=bs.getPosition();var radius=bs.getRadius();if(c3dl.rayIntersectsSphere(rayOrigin,rayDir,pos,radius)){return true;}}}
return false;}
this.rayIntersectsTriangles=function(rayOrigin,rayDir){var mat=c3dl.inverseMatrix(c3dl.peekMatrix());var rayorigin=c3dl.multiplyMatrixByVector(mat,rayOrigin);var raydir=c3dl.normalizeVector(c3dl.multiplyMatrixByDirection(mat,rayDir));var vert1=new C3DL_FLOAT_ARRAY(3);var vert2=new C3DL_FLOAT_ARRAY(3);var vert3=new C3DL_FLOAT_ARRAY(3);for(var i=0,len=this.primitiveSets.length;i<len;i++){if(this.getPrimitiveSets()[i].getType()!=="lines"){var vertices=this.primitiveSets[i].getVertices();for(var j=0,len2=vertices.length;j<len2;j+=9){vert1[0]=vertices[j];vert1[1]=vertices[j+1]
vert1[2]=vertices[j+2];vert2[0]=vertices[j+3];vert2[1]=vertices[j+4];vert2[2]=vertices[j+5];vert3[0]=vertices[j+6];vert3[1]=vertices[j+7];vert3[2]=vertices[j+8];if(c3dl.rayIntersectsTriangle(rayorigin,raydir,vert1,vert2,vert3)){return true;}}}}
return false;}
this.render=function(glCanvas3D,scene){if(glCanvas3D==null){c3dl.debug.logWarning('Geometry::render() called with a null glCanvas3D');return false;}
if(this.getPrimitiveSets()[0].getType()==="lines"){scene.getRenderer().renderLines(this.getPrimitiveSets()[0].getLines());}
else{if(this.firstTimeRender==true){for(var i=0,len=this.primitiveSets.length;i<len;i++){this.primitiveSets[i].setupVBO(glCanvas3D);}
this.firstTimeRender=false;}
scene.getRenderer().renderGeometry(this);if(scene.getBoundingVolumeVisibility()){for(var i=0,len=this.primitiveSets.length;i<len;i++){var bs=this.primitiveSets[i].getBoundingSphere();if(bs){bs.render(scene);}}}}}
this.setEffect=function(effect){this.effect=effect;}
this.setMaterial=function(material){for(var i=0,len=this.primitiveSets.length;i<len;i++){this.primitiveSets[i].setMaterial(material);}}
this.setTexture=function(texture){for(var i=0,len=this.primitiveSets.length;i<len;i++){this.primitiveSets[i].setTexture(texture);}}
this.update=function(timeStep,scaleVec,rotateMat){for(var i=0,len=this.primitiveSets.length;i<len;i++){var bs=this.primitiveSets[i].getBoundingSphere();if(bs){var test=c3dl.peekMatrix();bs.setPosition([test[12],test[13],test[14]]);bs.scale(scaleVec);bs.moveCenter(rotateMat);}}}}