
c3dl.BoundingSphere=function()
{this.longestVector=c3dl.makeVector(0,0,0);this.original=c3dl.makeVector(0,0,0);this.position=c3dl.makeVector(0,0,0);this.center=c3dl.makeVector(0,0,0);this.radius=0;this.maxMins=new C3DL_FLOAT_ARRAY(6)
this.init=function(vertices)
{var longestLengthFound=0;var vector=c3dl.makeVector(0,0,0);var currVector;lengthVerts=new C3DL_FLOAT_ARRAY(vertices.length/3),heightVerts=new C3DL_FLOAT_ARRAY(vertices.length/3),widthVerts=new C3DL_FLOAT_ARRAY(vertices.length/3);var j=0;for(var i=0,len=vertices.length/3;i<len;i++){lengthVerts[i]=vertices[j];heightVerts[i]=vertices[j+1];widthVerts[i]=vertices[j+2];j+=3}
this.maxMins[0]=c3dl.findMax(lengthVerts);this.maxMins[1]=c3dl.findMin(lengthVerts);this.maxMins[2]=c3dl.findMax(heightVerts);this.maxMins[3]=c3dl.findMin(heightVerts);this.maxMins[4]=c3dl.findMax(widthVerts);this.maxMins[5]=c3dl.findMin(widthVerts);this.center[0]=(this.maxMins[0]+this.maxMins[1])/2;this.center[1]=(this.maxMins[2]+this.maxMins[3])/2;this.center[2]=(this.maxMins[4]+this.maxMins[5])/2;for(var i=0;i<vertices.length;i+=3)
{vector[0]=vertices[i+0];vector[1]=vertices[i+1];vector[2]=vertices[i+2];c3dl.subtractVectors(vector,this.center,vector);currVector=c3dl.vectorLength(vector);if(currVector>longestLengthFound)
{longestLengthFound=currVector;this.longestVector=[vector[0],vector[1],vector[2]];}}
this.original[0]=this.longestVector[0];this.original[1]=this.longestVector[1];this.original[2]=this.longestVector[2];this.radius=c3dl.vectorLength(this.longestVector);}
this.setPosition=function(position)
{this.position[0]=position[0]+this.center[0];this.position[1]=position[1]+this.center[1];this.position[2]=position[2]+this.center[2];}
this.getTransform=function()
{var mat=c3dl.makePoseMatrix([1,0,0],[0,1,0],[0,0,1],this.position);var smat=c3dl.makeMatrix();c3dl.setMatrix(smat,this.radius,0,0,0,0,this.radius,0,0,0,0,this.radius,0,0,0,0,1);mat=c3dl.multiplyMatrixByMatrix(mat,smat);return mat;}
this.scale=function(scaleVec)
{var largestScale=scaleVec[0]>scaleVec[1]?scaleVec[0]:scaleVec[1];largestScale=largestScale>scaleVec[2]?largestScale:scaleVec[2];this.longestVector[0]=this.original[0]*largestScale;this.longestVector[1]=this.original[1]*largestScale;this.longestVector[2]=this.original[2]*largestScale;this.center[0]=(this.maxMins[0]*largestScale+this.maxMins[1]*largestScale)/2;this.center[1]=(this.maxMins[2]*largestScale+this.maxMins[3]*largestScale)/2;this.center[2]=(this.maxMins[4]*largestScale+this.maxMins[5]*largestScale)/2;this.radius=c3dl.vectorLength(this.longestVector);}
this.render=function(scene)
{if(scene.getBoundingVolumeVisibility())
{scene.getRenderer().renderBoundingSphere(this,scene.getCamera().getViewMatrix());}}
this.moveCenter=function(rotateMat)
{this.center=c3dl.multiplyMatrixByVector(rotateMat,this.center);}
this.getRadius=function()
{return this.radius;}
this.getMaxMins=function()
{return this.maxMins;}
this.getPosition=function()
{return c3dl.copyVector(this.position);}
this.getCenter=function()
{return c3dl.copyVector(this.center);}
this.getLongestVector=function()
{return c3dl.copyVector(this.longestVector);}
this.getCopy=function()
{var copy=new c3dl.BoundingSphere();copy.longestVector=c3dl.copyVector(this.longestVector);copy.original=c3dl.copyVector(this.original);copy.position=c3dl.copyVector(this.position);copy.center=c3dl.copyVector(this.center);copy.center=c3dl.copyVector(this.center);copy.maxMins=this.maxMins;return copy;}}