
c3dl.DirectionalLight=function()
{this.direction=c3dl.makeVector(0,0,1);this.type=c3dl.DIRECTIONAL_LIGHT;this.getDirection=function()
{return c3dl.copyVector(this.direction);}
this.setDirection=function(dir)
{this.direction=c3dl.normalizeVector(dir);}}
c3dl.DirectionalLight.prototype=new c3dl.Light;