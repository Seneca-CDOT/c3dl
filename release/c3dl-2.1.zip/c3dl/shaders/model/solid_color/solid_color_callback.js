
c3dl.solid_color_callback=function(renderingObj)
{var progObjID=renderingObj.getProgramObjectID();var geometry=renderingObj.getGeometry();var effect=geometry.getEffect();var renderer=renderingObj.getRenderer();var glCanvas3D=renderingObj.getContext();glCanvas3D.useProgram(progObjID);var modelViewMatrix=c3dl.peekMatrix();c3dl.matrixMode(c3dl.PROJECTION);var projectionMatrix=c3dl.peekMatrix();c3dl.matrixMode(c3dl.MODELVIEW);var modelViewProjMatrix=c3dl.multiplyMatrixByMatrix(projectionMatrix,modelViewMatrix);renderer.setUniformMatrix(progObjID,"modelViewProjMatrix",modelViewProjMatrix);renderer.setUniformf(progObjID,"color",effect.getParameter("color"));for(var coll=0;coll<geometry.getPrimitiveSets().length;coll++)
{var currColl=geometry.getPrimitiveSets()[coll];var normalAttribLoc=glCanvas3D.getAttribLocation(progObjID,"Normal");if(normalAttribLoc!=-1&&currColl.getNormals())
{renderer.setVertexAttribArray(progObjID,"Normal",3,currColl.getVBONormals());}
var texAttribLoc=glCanvas3D.getAttribLocation(progObjID,"Texture");if(texAttribLoc!=-1&&currColl.getTexCoords())
{renderer.setVertexAttribArray(progObjID,"Texture",2,currColl.getVBOTexCoords());}
renderer.setVertexAttribArray(progObjID,"Vertex",3,currColl.getVBOVertices());glCanvas3D.drawArrays(renderer.getFillMode(),0,currColl.getVertices().length/3);}}