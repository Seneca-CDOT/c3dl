
c3dl.SceneNode=c3dl.inherit(c3dl.Primitive,function(){c3dl._superc(this);this.children=[];});c3dl.SceneNode.prototype.getCopy=function(){var sceneNode=new c3dl.SceneNode();sceneNode.clone(this);return sceneNode;}
c3dl.SceneNode.prototype.clone=function(other){c3dl._super(this,arguments,"clone");for(var i=0,len=other.children.length;i<len;i++){this.addChild(other.children[i].getCopy());}}
c3dl.SceneNode.prototype.addChild=function(child){this.children.push(child);}
c3dl.SceneNode.prototype.findNode=function(nodeName){var child=null;if(nodeName==this.name){child=this;}
else{for(var i=0,len=this.children.length;i<len;i++){if(this.children[i]instanceof c3dl.SceneNode){child=this.children[i].findNode(nodeName);if(child!=null){break;}}}}
return child;}
c3dl.SceneNode.prototype.update=function(timeStep,scaleVec,rotateMat){c3dl._super(this,arguments,"update");c3dl.pushMatrix();if(!scaleVec){scaleVec=this.scaleVec;}
else if(this.scaleVec){scaleVec=c3dl.multiplyVectorByVector(scaleVec,this.scaleVec);}
if(!rotateMat){rotateMat=this.getRotateMat();}
else if(this.scaleVec){rotateMat=c3dl.multiplyMatrixByMatrix(rotateMat,this.getRotateMat());}
c3dl.multMatrix(this.getTransform());var velVec=c3dl.multiplyVector(this.linVel,timeStep);c3dl.addVectors(this.pos,velVec,this.pos);totalPos=c3dl.multiplyMatrixByVector(c3dl.peekMatrix(),this.pos);for(var i=0;i<this.children.length;i++){this.children[i].update(timeStep,scaleVec,rotateMat);}
this.pitch(this.angVel[0]*timeStep);this.yaw(this.angVel[1]*timeStep);this.roll(this.angVel[2]*timeStep);c3dl.popMatrix();}
c3dl.SceneNode.prototype.render=function(glCanvas3D,scene){c3dl.pushMatrix();c3dl.multMatrix(this.getTransform());for(var i=0,len=this.children.length;i<len;i++){this.children[i].render(glCanvas3D,scene);}
c3dl.popMatrix();}
c3dl.SceneNode.prototype.setTexture=function(textureName){for(var i=0,len=this.children.length;i<len;i++){this.children[i].setTexture(textureName);}}
c3dl.SceneNode.prototype.setMaterial=function(material){for(var i=0,len=this.children.length;i<len;i++){this.children[i].setMaterial(material);}}
c3dl.SceneNode.prototype.setEffect=function(effect){for(var i=0,len=this.children.length;i<len;i++){this.children[i].setEffect(effect);}}
c3dl.SceneNode.prototype.rayIntersectsTriangles=function(rayOrigin,rayDir){c3dl.pushMatrix();c3dl.multMatrix(this.getTransform());var passed=false;for(var i=0,len=this.children.length;i<len;i++){if(this.children[i].rayIntersectsTriangles(rayOrigin,rayDir)){passed=true;break;}}
c3dl.popMatrix();return passed;}
c3dl.SceneNode.prototype.rayIntersectsEnclosures=function(rayOrigin,rayDir){var passed=false;for(var i=0,len=this.children.length;i<len;i++){if(this.children[i].rayIntersectsEnclosures(rayOrigin,rayDir)){passed=true;break;}}
return passed;}
c3dl.SceneNode.prototype.getBoundingSpheres=function(){var boundingSpheres=[];for(var i=0;i<this.children.length;i++){if(this.children[i]instanceof c3dl.SceneNode){boundingSpheres=boundingSpheres.concat(this.children[i].getBoundingSpheres());}
else if(this.children[i]instanceof c3dl.Geometry){for(var j=0;j<this.children[i].getPrimitiveSets().length;j++){if(this.children[i].getPrimitiveSets()[j].getBoundingSphere()){boundingSpheres=boundingSpheres.concat(this.children[i].getPrimitiveSets()[j].getBoundingSphere());}}}}
return boundingSpheres;}
c3dl.SceneNode.prototype.getAllVerts=function(){var allverts=[];var numverts=0;var temp2=[],temp3=[];c3dl.pushMatrix();c3dl.multMatrix(this.getTransform());for(var i=0;i<this.children.length;i++){if(this.children[i]instanceof c3dl.SceneNode){allverts=allverts.concat(this.children[i].getAllVerts());}
else if(this.children[i]instanceof c3dl.Geometry){for(var j=0;j<this.children[i].getPrimitiveSets().length;j++){if(this.children[i].getPrimitiveSets()[j].getBoundingSphere()){var temp=this.children[i].getPrimitiveSets()[j].getBoundingSphere().getMaxMins();c3dl.multiplyMatrixByVector(c3dl.peekMatrix(),[temp[0],temp[2],temp[4]],temp2);c3dl.multiplyMatrixByVector(c3dl.peekMatrix(),[temp[1],temp[3],temp[5]],temp3);allverts=allverts.concat(temp2);allverts=allverts.concat(temp3);}}}}
c3dl.popMatrix();return allverts;}
c3dl.SceneNode.prototype.center=function(newcenter){for(var i=0;i<this.children.length;i++){if(this.children[i]instanceof c3dl.SceneNode){this.children[i].center(newcenter);}
else if(this.children[i]instanceof c3dl.Geometry){var temp=new c3dl.SceneNode();for(var j=0;j<this.children.length;j++)
temp.addChild(this.children[j]);this.children=[];this.children[i]=temp;temp.setTransform(c3dl.makePoseMatrix([1,0,0],[0,1,0],[0,0,1],[-newcenter[0],-newcenter[1],-newcenter[2]]));}}}