/*
  Copyright (c) 2008 Seneca College
  Licenced under the MIT License (http://www.c3dl.org/index.php/mit-license/)
*/

c3dl.solid_color_fs = 

"void main(void) {" + 
"  gl_FragColor = gl_Color;" + 
"}";
