
c3dl.RenderingObject=function()
{this.getContext=function()
{}
this.getGeometry=function()
{}
this.getProgramObjectID=function()
{}
this.getRenderer=function()
{}}