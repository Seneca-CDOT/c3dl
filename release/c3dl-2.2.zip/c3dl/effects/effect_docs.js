
c3dl.effects={};c3dl.effects.STD_EFFECT=0;c3dl.effects.SOLID_COLOR=0;c3dl.effects.GOOCH=0;c3dl.effects.CARTOON=0;c3dl.effects.SEPIA=0;c3dl.effects.GREYSCALE=0;c3dl.effects.STANDARD=1;